﻿using DavidTielke.PMA.CrossCutting.DataClasses;

namespace DavidTielke.PMA.Logic.PersonManagement;

public interface IPersonManager
{
    List<Person> GetAllAdults();
    List<Person> GetAllChildren();
}